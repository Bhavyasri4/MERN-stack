/*const express = require('express');
const mongoose = require('mongoose');
const app = express();

const uri = "mongodb+srv://bhavyasri46:4312@products.qmqpp.mongodb.net/?retryWrites=true&w=majority&appName=products";

mongoose.connect(uri, { dbName: 'student' })
    .then(() => {
        console.log("Database connected");
        const schem = new mongoose.Schema({Name:String,Roll:Number,Marks:[Number]})
    const coll = mongoose.model('student',schem)
    console.log('collection created')
    app.use(express.urlencoded({extended:true}))

    app.get('/',(req,res)=>
    {
      res.sendFile(path.join(__dirname,'/index.html'))
    })
    app.get('/all',async(req,res)=>
    {
      res.json(await coll.find())
    })
    app.post('/submit',async(req,res)=>
    {
      let {Name,Roll,Marks} = req.body;
      let result = new coll ({Name,Roll,Marks} )
      await result.save() ;
      res.send("Data Successfuly saved")
    })
    

}).catch(
    (err)=>
    {
        console.error("Error ", err.message)
    }
)
app.listen(3500,(req,res)=>
{
    console.log('server runs on http://127.0.0.1:3500')
})*/
let express = require ('express')
let app = express()
let mongoose = require ('mongoose')
let path = require('path')
app.use(express.static('public'))
let uri = "mongodb+srv://bhavyasri46:4312@products.qmqpp.mongodb.net/?retryWrites=true&w=majority&appName=products";
mongoose.connect(uri,{dbName:'student'}).then(()=>
{
    console.log("Database Connected")
    const schem = new mongoose.Schema({Name:String,Roll:Number,Marks:[Number]})
    const coll = mongoose.model('students',schem)
    console.log('collection created')
    app.use(express.urlencoded({extended:true}))

    app.get('/',(req,res)=>
    {
      res.sendFile(path.join(__dirname,'/index.html'))
    })
    app.get('/all',async(req,res)=>
    {
      res.json(await coll.find())
    })
    app.post('/submit',async(req,res)=>
    {
      let {Name,Roll,Marks} = req.body;
      let result = new coll ({Name,Roll,Marks} )
      await result.save() ;
      res.send("Data Successfuly saved")
    })
    

}).catch(
    (err)=>
    {
        console.error("Error ", err.message)
    }
)
app.listen(3500,(req,res)=>
{
    console.log('server runs on http://127.0.0.1:3500')
})