let url=require('url')
let strurl="http://www.kits.com/Home?name=bhavya&roll=507"
let parsedurl=url.parse(strurl,true)
console.log(parsedurl.protocol);
console.log(parsedurl.hostname);
console.log(parsedurl.pathname);
console.log(parsedurl.query);