let http=require('http')
let host="127.0.0.1"
let port=5000
let server=http.createServer((req,res)=>{
    if(req.url=="/new"){
    res.writeHead(200);
    res.write("New page")
    res.end();
    }else if(req.url=="/old"){
        res.writeHead(200);
    res.write("Old page")
    res.end();
    }else{
        res.writeHead(404);
    res.write("page not found")
    res.end();
    }
})
server.listen(port,host,()=>{
    console.log("server run on http://"+host+":"+port);
})