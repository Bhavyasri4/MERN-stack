const express = require('express');
const app = express();
let host="127.0.0.1"
let port=5000
app.use(express.json());
app.post('/data', (req, res) => {
    console.log(req.body);
    res.json({
        message: 'Data received successfully!',
        receivedData: req.body
    });
});
app.listen(port,host,()=>{
    console.log("server run on http://"+host+":"+port);
})