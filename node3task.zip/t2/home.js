let names=[
    {
        id :501,
        Name :"bhavya"
    } ,
    {
        id :502,
        Name : "maggie"
    },
    {
        id :503,
        Name : "niha"
    }, {
        id :504,
        Name : "kousi"
    }
]
module.exports=names