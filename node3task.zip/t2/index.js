
let express=require('express')
let app=express()
let home=require('./home')


app.get('/welcome',(req,res)=>{
    res.send("welcome page")
})
app.get('/home',(req,res)=>{
    res.json(home)
})
app.listen(3500,()=>{
    console.log("server runs on http://127.0.0.1:3500")
})