let http = require('http')
 let host = "127.0.0.1"
 let port = 4000
 let fs = require('fs')
 let path = require('path')
 let FilePath = path.join(__dirname,'index.html')
 let server = http.createServer((req,res)=>{
 fs.readFile(FilePath,(err,data)=>{
 if (err) {
 res.writeHead(500, { 'Content-Type': 'text/plain' });
 res.end('Error in loading');
 } else {
 res.writeHead(200, { 'Content-Type': 'text/html' });
 res.end(data);
 }
 })
 })
 server.listen(port,host,()=>{
 console.log("Server runs on http://127.0.0.1:4000")
 })