/*import React, { Component } from 'react'
import './App.css'
//import im1 from './image.jpg'

export class App extends Component {
  render() {
    return (
      <div>
        <h1>Hello my </h1>
        
        <form action='/submit' method='post'>
        <label for="name">name: </label>
        <input type='text' name='name' placeholder='your name' required/><br></br>
        <label for="age">age: </label>
        <input type='number' name='age' placeholder='your age' required/><br></br>
        <button type='submit'>click</button>
        

        </form>
        <table>
          
          <th>
            <td>name
            </td>
            <td>roll</td>
            <td>age</td>
          </th>
          <tr>
            <td>bhavya</td>
            <td>2</td>
            <td>20</td>
          </tr>
          <tr>
            <td>bhavya</td>
            <td>2</td>
            <td>20</td>
          </tr>
          <tr>
            <td>bhavya</td>
            <td>2</td>
            <td>20</td>
          </tr>
        </table>
      </div>
    )
  }
}

export default App*/

//CSS TYPES

import React, { Component } from 'react'
import './App.css'
import pg from './page.module.css'
export class App extends Component {
  render() {
  let mylist={
    color:"green"
  }

    return (
      <div>
        <h1 style={mylist}>
          a+b={5+6}
        </h1>
        <h1 style={{color:'red'}}>
          a+b={5+6}
        </h1>
        <h1>hi</h1>
        <h1 className={pg.page}>
          Hello
        </h1>
      </div>
    )
  }
}

export default App
