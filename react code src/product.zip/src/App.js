import React, { useState } from 'react';
import p1 from './pexel.jpg';
import p2 from './pexel.jpg';
import p3 from './pexel.jpg';

const products = [
  { id: 1, name: 'Product1', price: 50, image: p1 },
  { id: 2, name: 'Product2', price: 75, image: p2 },
  { id: 3, name: 'Product3', price: 100, image: p3 },
];

function ProductDetails() {
  const [selectedProducts, setSelectedProducts] = useState([]);

  const handleCheckboxChange = (product) => {
    if (selectedProducts.includes(product)) {
      setSelectedProducts(selectedProducts.filter((p) => p !== product));
    } else {
      setSelectedProducts([...selectedProducts, product]);
    }
  };

  const calculateTotalPrice = () => {
    return selectedProducts.reduce((acc, product) => acc + product.price, 0);
  };

  const calculateTotalCount = () => {
    return selectedProducts.length;
  };

  return (
    <div>
      <h3>Product List:</h3>
      <div style={{ display: 'flex', gap: '20px' }}>
        {products.map((product) => (
          <div key={product.id} style={{ textAlign: 'center' }}>
            <img src={product.image} alt={product.name} width="150" />
            <p>{product.name}</p>
            <p>Price: ${product.price}</p>
            <input
              type="checkbox"
              checked={selectedProducts.includes(product)}
              onChange={() => handleCheckboxChange(product)}
            />
          </div>
        ))}
      </div>
      <h3>Total selected items: {calculateTotalCount()}</h3>
      <h3>Total price: ${calculateTotalPrice()}</h3>
    </div>
  );
}

export default ProductDetails;
