import React, { Component } from 'react';
import './App.css';
import passport from './passport.jpg'

class App extends Component {
  render() {
    return (
      <div className='home-page'>
        <div className='name-section'>
        <h1>BALLA BHAVYASRI PRAVALLIKA</h1>
        </div>
        <div className='Photo-section'>
        {<img src={passport} alt="Your Name" className="profile-photo" />}
        </div>  

        <div>
          <h3>&nbsp;Contact Information</h3>
          <p>&nbsp;&nbsp;Email:21jr1a0507@gmail.com</p>
          <p>&nbsp;&nbsp;Phone:9441936771</p>
          <p>&nbsp;&nbsp;LinkedIn:https://www.linkedin.com/in/balla-bhavyasri-pravallika-673223257</p>
        
        </div>

        <div>
          <h3>&nbsp;carrier objective</h3>
          <p>
          &nbsp;&nbsp;I am seeking a company where I can use my experience and education to help the company meet and 
          surpass its goals. 
          </p>
        
        </div>

       
        <h3>&nbsp;Educational Information</h3>
        <table>
  <tr>
    <th>Qualification</th>
    <th>Institute</th>
    <th>Year</th>
    <th>CGPA</th>
  </tr>
  <tr>
    <td>B.Tech</td>
    <td>KKR & KSR Institute of Technology and Sciences</td>
    <td>2021-2025</td>
    <td>8.9</td>
  </tr>
  <tr>
    <td>Intermediate</td>
    <td>SRI CHAITANYA JUNIOR COLLAGE</td>
    <td>2019-2021</td>
    <td>8.9</td>
  </tr>
  <tr>
    <td>SSC</td>
    <td>SIMS MY SCHOOL</td>
    <td>2019</td>
    <td>9.8</td>
  </tr>
</table>

        
        <div>
          <h3>Project Details</h3>
          <div>
            <ul>
              <li><b>Title :</b> PE-HE-AD(Pet-Health- Adoption)</li>
              <li>Technologies used : HTML,CSS</li>
             <li>Description 
: The website is related to the pets and the objective of this project is divided 
into 4 modules </li>
            </ul>
          </div>
          <div>
            
            <ul>
              <li>Module 1:It contains the information of nearby pet hospital</li>
              <li>Module 2:It contains the buying and selling of pets</li>
              <li>Module 3:It contain the Pet accessories</li>
              <li>Module 4:It contain details of vaccines</li>
            </ul>
          </div>
        </div>
        <div>
          <h3>Skills</h3>
          <ul>
            <li>C</li>
            <li>Python</li>
            <li>HTML/CSS</li>
            <li>Java</li>
            <li>SQL</li>
          </ul>
        </div>
        <div>
          <h3>&nbsp;CERTIFICATIONS</h3>
          <p>&nbsp;&nbsp;Certified from edx in HTML&CSS.</p>
          <p>&nbsp;&nbsp;Certified in Programming in JAVA from NPTEL.</p>
          <p>&nbsp;&nbsp;Certified in Networking Essential through CISCO</p>
        
        </div>
        <div>
          <h3>&nbsp;Declaration</h3>
          <p>&nbsp;&nbsp;I hereby declare that the above listed information and evidence are true to the best of my knowledge. </p>
          <p>
          &nbsp;&nbsp;Place: 
          </p>
          <p>
          &nbsp;&nbsp;Date: 
          </p>
          <p>
          &nbsp;&nbsp;Signature: 
          </p>
        </div>
      </div>
    );
  }
}

export default App;
