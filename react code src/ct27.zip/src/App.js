/*import React, { Component } from 'react';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userName: "",
      finalValue:""
    };
  }

  changeUserName = (event) => {
    this.setState({ userName: event.target.value });
  }
  eventHandler=(event)=>{
    event.preventDefault()
    this.setState({finalValue:this.state.userName})
  }

  render() {
    return (
      <div>
        <form onSubmit={this.eventHandler}>
        <input 
          type="text" placeholder='UserName' onChange={this.changeUserName} />
    
        <button type='submit'>click</button>
        </form>
        <h1>UserName: {this.state.finalValue}</h1>
      </div>
    );
  }
}

export default App;*/

// reacr conditional render
/*import React, { Component } from 'react'

export class App extends Component {
  render() {
    const myli=["home","news","contact","about"]
    const listitem=myli.map((li)=><li>{li}</li>)
    return (
      <div>
        <ul>{listitem}</ul>
      </div>
    )
  }
}

export default App*/

//react fragment
/*import React, { Component } from 'react'

export class App extends Component {
  render() {
    return (
      <React.Fragment>Hello1</React.Fragment>
    )
  }
}

export default App*/

//
/*import React, { Component } from 'react';

export class App extends Component {
  data = [
    { id: 1001, name: "bhqvya" },
    { id: 1002, name: "maggie" },
    { id: 1003, name: "nihq" }
  ];

  render() {
    return (
      <div>
        <table>
          <thead>
            <tr>
              <th>id</th>
              <th>name</th>
            </tr>
          </thead>
          <tbody>
            {this.data.map((val, key) => {
              return (
                <tr key={key}>
                  <td>{val.id}</td>
                  <td>{val.name}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }
}

export default App;*/
import React, { Component } from 'react'

 class App extends Component {
  constructor(props){
   super(props)
   this.inputref=React.createRef()
  }
  clickHandler=()=>{
    this.inputref.current.focus();
    alert(this.inputref.current.ref)
  }
  render() {
    return (
      <div><input type='text' ref={this.inputref}></input>
      <input type='button' value='click' onClick={this.clickHandler}/>
      </div>
    )
  }
}

export default App
