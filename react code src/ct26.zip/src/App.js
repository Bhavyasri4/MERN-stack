/*import React, { Component } from 'react'
import { name } from 'tar/types'

class App extends Component {
  constructor(props){
    super(props)
    this.state={
      name:"bhavya",
      Role:"hr"
    }
  }
  onChange=()=>{
    this.setState({role:'dev'})
  }
  render() {
    return (
      <div>Name:{this.state.name}<br/>
      Role:{this.state.role}<br/>
      <button onClick={this.onChange}>click</button>
      </div>
    )
  }
}

export default App*/

//functional component

/*import React, { useState } from 'react';
import Pexel from './pexel.jpg';

function App() {
  const [count, setCount] = useState(250); 

  const inc = () => {
    setCount(count + 20); 
  };

  const dec = () => {
    setCount(count - 20); 
  };

  return (
    <div>
      <img 
        src={Pexel} 
        style={{ height: `${count}px`, width: `${count}px`, marginLeft: '40%' }} 
        alt='no' 
      />
      {count>=250?count:setCount(250)}
      <div style={{ textAlign: 'center', marginTop: '20px' }}>
        <h1>Count: {count}</h1>
        <button onClick={dec}>Decrement</button>&nbsp;&nbsp;&nbsp;&nbsp;
        <button onClick={inc}>Increment</button>
      </div>
    </div>
  );
}

export default App;*/


/*import React, { Component } from 'react'

export class App extends Component {
  constructor(props){
    super(props)
    this.forceUpdateState=this.forceUpdateState.bind(this)
  }
  forceUpdateState(){
    this.forceUpdate()
  }
  render() {
    return (
      <div>Random Value:{parseInt(Math.random()*100

      )}
      <button onClick={this.forceUpdateState}>click</button>
      Random Value:{(Math.random()*100)}</div>
    )
  }
}

export default App*/

//react Dom
/*import React, { Component } from 'react';
import ReactDOM from 'react-dom';

export class App extends Component {
  constructor(props) {
    super(props);
    this.changeColor = this.changeColor.bind(this);
  }

  changeColor() {
    const myh1 = document.getElementById('A1'); 
    if (myh1) {
      myh1.style.color = "green"; 
      myh1.style.border = "2px solid green"; 
    }
  }

  render() {
    return (
      <div>
        <h1 id='A1'>Hello my dear</h1>
        <button onClick={this.changeColor}>Click</button>
      </div>
    );
  }
}

export default App;*/

import React, { Component } from 'react';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      userName: ""
    };
  }

  changeUserName = (event) => {
    this.setState({ userName: event.target.value });
  }

  render() {
    return (
      <div>
        <input 
          type="text" 
          placeholder='UserName' 
          onChange={this.changeUserName} 
        />
        <h1>UserName: {this.state.userName}</h1>
      </div>
    );
  }
}

export default App;
