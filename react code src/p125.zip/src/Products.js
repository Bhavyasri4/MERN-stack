/*import React, { Component } from 'react'
import './App.css'
class Products extends Component {
  render() {
    return (
      <div className='navbar'>Products
       <ul className='navitems'>
        <li>Iphone</li>
        <li>moto</li>
        <li>realme</li>
       </ul>
       </div>
    )
  }
}

export default Products*/

import React, { Component } from 'react'
 class Products extends Component {
  render() {
    return (
      <div>
        <p>
            Amount:{this.props.bal}<br/> Name:{this.props.name}
        </p>
      </div>
    )
  }
}

export default Products