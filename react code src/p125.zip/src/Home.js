/*import React, { Component } from 'react'

 class Home extends Component {
  render() {
    return (
      <p1>home page</p1>
    )
  }
}

export default Home*/

import React from 'react'

function Home() {
  return (
    <div>
      
    </div>
  )
}

export default Home
