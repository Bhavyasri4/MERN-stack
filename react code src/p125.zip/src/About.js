import React, { Component } from 'react'

class About extends Component {
  render() {
    return (
      <p>about page</p>
    )
  }
}

export default About