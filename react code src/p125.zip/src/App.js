/*import React, { Component } from 'react';
import Home from './Home';
import About from './About';
import Products from './Products';

export class App extends Component {
  render() {
    return (
      <div>
        <Home />
        <Products />
        <About />
      </div>
    );
  }
}

export default App;*/

//state and props using class
/*import React, { Component } from 'react'
import Products from './Products'
import Home from './Home'


export class App extends Component {
  obj={
    Name:'raj',
    Age:23
  }
  render() {
    return (
      <div
      ><p>Name:{this.obj.Name}<br/>Age:{this.obj.Age}</p>
      <Products bal='20000'  name='bhavya'/>
      <Products bal='20000'  name={this.obj.Name}/>
      <Home Account="1098" age={this.obj.Age}/>
      
      </div>
    )
  }
}

export default App*/

//States and props using function
import React from 'react'

function App() {
  return (
    <div>
      
    </div>
  )
}

export default App


