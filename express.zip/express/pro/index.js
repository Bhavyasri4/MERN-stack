/*let express=require('express')
let app=express()

app.get('/',(req,res)=>{
    res.json(req.query)
})
let path=require('path')
app.use(express.static('public'));
app.get('/',(req,res)=>{
    res.sendFile(path.join(__dirname,'/index.html'))
})
app.post('/submit',(req,res)=>{
    let {Name,Price}=req.body
    console.log(`<h1>Name:${Name} Price:${Price}</h1>`)
})
app.listen(3500,()=>{
    console.log('server runs on http://127.0.0.1:3500')
})*/


//database connect


let express=require('express')
let app=express()

let mongoose=require('mongoose')
let uri="mongodb+srv://bhavyasri46:4312@products.qmqpp.mongodb.net/?retryWrites=true&w=majority&appName=products"
mongoose.connect(uri,{dbName:'pro'}).then(()=>{
    console.log("database connect")
    const Schem=new mongoose.Schema({Name:String,Price:Number})
    const col1=mongoose.model('mobile',Schem)
    console.log('collection created')
    app.get('/',(req,res)=>{
        res.sendFile(__dirname+"/index.html")

    })
    app.get('/all',async (req,res)=>{
        res.json(await col1.find)
    })
    app.use(express.urlencoded({extended:true}))
    app.post('/submit',async (req,res)=>{
        let {Name,Price}=req.body
        let result=new  col1({Name,Price})
        await result.save()
        res.send("Databsaved")
    })
    app.put('/update',async(req,res)=>{
        let result=await col1.updateOne({"Name":"iphone"},{$set:{"Price":1200}})
        res.send("Data Successfully saved")
    })
    app.delete('/delete',async(req,res)=>{
        await col1.deleteOne({"Name":"realme"})
        res.send("deleted")
    })
}).catch(
    (err)=>{
        console.log("Error",err.message)
    })
    app.listen(8000,()=>{
        console.log("server run http://127.0.0.1:8000")
    }
    )