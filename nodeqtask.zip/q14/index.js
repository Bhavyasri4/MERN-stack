let express = require('express');
let app = express();
let port = 5000;
let host = '127.0.0.1';
app.get('/lowercase', (req, res) => {
    const text = req.query.text;


    if (!text) {
        res.send("Invalid");
    } else {
        let lower = text.toLowerCase();
        res.send(`<html>
            <body>
            <p>Original text: ${text}<br/>
            <p>Lowercase text: ${lower}<br/>
            </body>
            </html>`);
    }
});
app.listen(port, host, () => {
    console.log(`Server is running at http://127.0.0.1:5000`);
});
