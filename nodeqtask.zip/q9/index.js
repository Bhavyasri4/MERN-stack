let express = require('express');
let app = express();
let port = 5000;
let host = '127.0.0.1';
app.get('/square', (req, res) => {
    const num = parseInt(req.query.number);

    if (isNaN(num)) {
        res.send("Invalid ");
    } else {
        const squ= num * num;
        res.send(`Square is:${squ}`);
    }
});
app.get('/cube', (req, res) => {
    const num = parseInt(req.query.number);

    if (isNaN(num)) {
        res.send("Invalid ");
    } else {
        const cub = num * num;
        res.send(`Cube is:${cub}`);
    }
});
app.listen(port, host, () => {
    console.log(`Server is running at http://127.0.0.1:5000`);
});
