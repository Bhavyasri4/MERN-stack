let express = require('express');
let app = express();
let port = 5000;
let host = '127.0.0.1';
app.get('/concat', (req, res) => {
    let str1 = req.query.string1; 
    let str2 = req.query.string2; 

    if (str1 === undefined || str2 === undefined) {
        res.send("Invalid.");
    } else {
        let result = str1 + str2; 
        res.send(`Concatenation of the two strings is: ${result}`);
    }
});
app.listen(port, host, () => {
    console.log(`Server is running at http://127.0.0.1:5000`);
});
