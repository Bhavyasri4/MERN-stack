let express = require('express');
let app = express();
let port = 5001;
let host = '127.0.0.1';
function factorial(n) {
    if (n < 0) return "Invalid input: Factorial is not defined for negative numbers.";
    if (n === 0 || n === 1) return 1;
    return n * factorial(n - 1);
}
app.get('/factorial', (req, res) => {
    let num = parseInt(req.query.number);

    if (isNaN(num)) {
        res.send("Invalid");
    } else {
        let result = factorial(num);
        res.send(`Factorial  is: ${result}`);
    }
});
app.listen(port, host, () => {
    console.log(`Server is running at http://127.0.0.1:5001`);
});
