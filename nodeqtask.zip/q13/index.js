let express = require('express');
let app = express();
let port = 5000;
let host = '127.0.0.1';
app.get('/length', (req, res) => {
    const str = req.query.string;

    if (str === undefined) {
        res.send("Invalid ");
    } else {
        let len = str.length; 
        res.send(`Length of the string is : ${len}`);
    }
});
app.listen(port, host, () => {
    console.log(`Server is running at http://${host}:${port}`);
});
