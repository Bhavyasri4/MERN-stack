const express = require('express');
const app = express();
const port = 5000;
let host='127.0.0.1'
app.get('/greet', (req, res) => {
  const name = req.query.name; 
  if (name) {
    res.send(`Hello, ${name}!`); 
  } else {
    res.send('Hello!');
  }
});
app.listen(port,host, () => {
  console.log(`Server running at http://127.0.0.1:5000`);
});
