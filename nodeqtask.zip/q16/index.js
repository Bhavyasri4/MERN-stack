let express = require('express');
let app = express();
let port = 5000;
let host = '127.0.0.1';
app.get('/substring', (req, res) => {
    let str = req.query.string;
    let start = parseInt(req.query.start);
    let end = parseInt(req.query.end);

    if (str === undefined) {
        res.send("Invalid ");
    } else {
        let len = str.substring(start,end); 
        res.send(`The substring is : ${len}`);
    }
});
app.listen(port, host, () => {
    console.log(`Server is running at http://127.0.0.1:5000`);
});
