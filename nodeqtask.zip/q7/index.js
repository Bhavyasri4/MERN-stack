let express = require('express');
let app = express();
let port = 5000;
let host='127.0.0.1'
app.get('/calculator', (req, res) => {
    const num1 = parseFloat(req.query.num1);
    const num2 = parseFloat(req.query.num2);
    const operation = req.query.operation;

    if (isNaN(num1) || isNaN(num2)) {
        res.send("Invalid")
    }else{
        let sum=num1+num2;
        let sub=num1-num2;
        let mul=num1*num2;
        let div=num1/num2;
        res.send(`<html>
            <body>
            <p>Sum is:${sum}<br/>
            <p>Subtraction is:${sub}<br/>
            <p>Multiplicatio is:${mul}<br/>
            <p>Divison is:${div}<br/>
            </body>
            </html>
            `)
    }})
    app.listen(port,host, () => {
        console.log(`Server is running at http://127.0.0.1:5000`);
    });
