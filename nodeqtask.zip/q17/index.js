let express = require('express');
let app = express();
let port = 5001;
let host = '127.0.0.1';
app.get('/modulo', (req, res) => {
    let a = parseInt(req.query.a);
    let b = parseInt(req.query.b);

    if (isNaN(a) || isNaN(b)) {
        res.send("Invalid ");
    } else if (b === 0) {
        res.send("Invalid input: Division by zero is not allowed.");
    } else {
        let result = a % b; 
        res.send(`The result is: ${result}`);
    }
});
app.listen(port, host, () => {
    console.log(`Server is running at http://127.0.0.1:5001`);
});
