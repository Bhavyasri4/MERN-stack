let express = require('express');
let app = express();
let port = 5000;
let host='127.0.0.1'
const convertctof = (celsius) => {
    return (celsius * 9/5) + 32;
};
app.get('/convert', (req, res) => {
    let celsius = parseFloat(req.query.celsius);
    
    if (isNaN(celsius)) {
        return res.status(400).json({ error: 'Invalid Celsius value' });
    }

    const fahrenheit = convertctof(celsius);
    res.json({ celsius, fahrenheit });
});
app.listen(port, () => {
    console.log(`Server is running at http://127.0.0.1:5000`);
});
