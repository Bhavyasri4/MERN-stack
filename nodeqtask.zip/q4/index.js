let express = require('express');
let app = express();
let port = 5000;
let host='127.0.0.1'
app.get('/multiply', (req, res) => {
    const x = parseFloat(req.query.x);
    const y = parseFloat(req.query.y);

    if (isNaN(x) || isNaN(y)) {
        return res.status(400).send('Invalid query parameters. Please provide valid numbers for x and y.');
    }

    const product = x * y;
    res.json({ product });
});
app.get('/reverse', (req, res) => {
    const text = req.query.text;

    if (typeof text !== 'string') {
        return res.status(400).send('Invalid query parameter. Please provide a valid string for text.');
    }

    const reversedText = text.split('').reverse().join('');
    res.json({ reversed: reversedText });
});

// Start the server
app.listen(port,host, () => {
    console.log(`Server running at http://127.0.0.1:5000`);
});
