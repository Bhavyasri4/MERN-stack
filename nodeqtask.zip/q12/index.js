let express = require('express');
let app = express();
let port = 5000;
let host = '127.0.0.1';
app.get('/power', (req, res) => {
    let b = parseFloat(req.query.base);
    let e = parseFloat(req.query.exponent);

    if (isNaN(b)||isNaN(e)) {
        res.send("Invalid ");
    } else {
        let result = Math.pow(b, e);
        res.send(`Result is:${result}`);
    }
});
app.listen(port, host, () => {
    console.log(`Server is running at http://127.0.0.1:5000`);
});
