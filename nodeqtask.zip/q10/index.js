let express = require('express');
let app = express();
let port = 5001;
let host = '127.0.0.1';
app.get('/circle', (req, res) => {
    const r = parseFloat(req.query.radius);

    if (isNaN(r)) {
        res.send("Invalid ");
    } else {
        const area= 3.14*r* r;
        res.send(`Area of circle is:${area}`);
    }
});
app.listen(port, host, () => {
    console.log(`Server is running at http://127.0.0.1:5001`);
});
