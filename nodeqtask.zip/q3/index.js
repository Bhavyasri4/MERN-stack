let express = require('express');
let app = express();
let port = 5000;
let host='127.0.0.1'
app.get('/fullname', (req, res) => {
    const first = req.query.first;
    const last = req.query.last;
    if (!first || !last) {
        return res.status(400).send('Both first and last name must be provided.');
    }

    const fullName = `Full name: ${first} ${last}`;
    res.send(fullName);
});

app.listen(port, () => {
    console.log(`Server is running at http://127.0.0.1:5000`);
});
