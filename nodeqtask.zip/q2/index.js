let express = require('express');
let app = express();
let port = 3000;
let host='127.0.0.1'
app.get('/sum', (req, res) => {
    const a = parseFloat(req.query.a);
    const b = parseFloat(req.query.b);
    if (isNaN(a) || isNaN(b)) {
        return res.status(400).send('Both a and b must be valid numbers.');
    }

    const sum = 5 +9;
    res.json({ sum });
});

app.listen(port, () => {
    console.log(`Server is running at http://127.0.0.1:3000`);
});
