/*let a=require('to-case'); 
console.log(a.upper("hello"))*/
/*let http=require('http')
let host="127.0.0.1"
let port=5000
let server=http.createServer((req,res)=>{
    if(req.url=="/Home"){
    res.writeHead(200);
    res.write("Home page")
    res.end();
    }else if(req.url=="/welcome"){
        res.writeHead(200);
    res.write("welcome page")
    res.end();
    }else{
        res.writeHead(404);
    res.write("page not found")
    res.end();
    }
})
server.listen(port,host,()=>{
    console.log("server run on http://"+host+":"+port);
})*/
/*const cal = require('./fun');
const { sum, sub } = cal;
//console.log(cal.sum(5,9));
console.log(sum(4, 5)); // Outputs: 9
console.log(sub(10, 3)); // Outputs: 7 (for testing the sub function)*/
/*let url=require('url')
let strurl="http://www.kits.com/Home?name=bhavya&roll=507"
let parsedurl=url.parse(strurl,true)
console.log(parsedurl.protocol);
console.log(parsedurl.hostname);
console.log(parsedurl.pathname);
console.log(parsedurl.query);*/
/*let url=require('url')
let strurl={
    protocol:"http:",
    hostname:"/www.kits.com",
    pathname:"/Course",
    query:{Name:"nodejs",Price:"17000"}

}
let  finalurl=url.format(strurl)
console.log(finalurl)*/
/*let url=require('url')
let baseurl="http://www.cse1.com/"
let relativeurl="/StudentPage?name=bhavya@Roll=507"
let formaturl=url.resolve(baseurl,relativeurl)
console.log(formaturl)*/
/*let url=require('url')
let strurl="ttp://www.cse1.com/StudentPage?name=bhavya@Roll=507"
let parseurl=url.parse(strurl,true)
console.log(parseurl)*/
//queryy to string
/*let queryString=require('querystring')
let qs="name=bhavya&sal=600000&Dtp=dev"
let finalquery=queryString.parse(qs)
console.log(finalquery)*/
//string to query
/*let queryString=require('querystring')
let qs={ name: 'bhavya', sal: '600000', Dtp: 'dev' }
let finalquery=queryString.stringify(qs)
console.log(finalquery)*/
//encoding and decoding
let queryString=require('querystring')
let str="kits guntur$"
let enc=queryString.escape(str)
console.log(enc)
let destr=queryString.unescape(enc)
console.log(destr)

//        Express.js

/*let express=require('express')
let app=express()
let product=require('./products')
app.use('/products',product)

app.get('/welcome',(req,res)=>{
    res.send("welcome page")

})

app.listen(3500,()=>{
    console.log("server runs on http://127.0.0.1:3500")
})*/
/*let express=require('express')
let app=express()
let product=require('./products')


app.get('/welcome',(req,res)=>{
    res.send("welcome page")
})
app.get('/products',(req,res)=>{
    res.json(product)
})
app.listen(3500,()=>{
    console.log("server runs on http://127.0.0.1:3500")
})*/


let express=require('express')
let app=express()
let product=require('./products')


app.get('/welcome',(req,res)=>{
    res.send("welcome page")
})
app.get('/products',(req,res)=>{
    res.json(product)
})
app.get('/products/:id',(req,res)=>{
    const id=Number(req.params.id)
    const Product=product.find((pro)=>pro.id===id)
    res.json(Product)
})
app.listen(3500,()=>{
    console.log("server runs on http://127.0.0.1:3500")
})
