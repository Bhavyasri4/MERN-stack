/*let express=require('express')
let router=express.Router()
router.get('/mobiles',(req,res)=>{
    res.send(`<h1>Iphone</h1>`)
})
router.post('/Course',(req,res)=>{
    res.send(`<h1>Node js</h1>`)
})

module.exports=router*/
let mobiles=[
    {
        id :1001,
        Name :"oppo",
        price :"26000"
    } ,
    {
        id :1002,
        Name : "Iphone",
        price :"39000 ",
    },
    {
        id :1003,
        Name : "realme",
        price :"19000 ",
    }, {
        id :1004,
        Name : "moto",
        price :"12000 ",
    }
]
module.exports=mobiles