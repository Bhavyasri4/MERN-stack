const http = require('http');
const url = require('url');

const host = "127.0.0.1";
const port = 5000;

const server = http.createServer((req, res) => {
    const parsedUrl = url.parse(req.url, true); 
    const path = parsedUrl.pathname;

    if (path === "/") {
        res.writeHead(200);
        res.write("Home page");
        res.end();
    } else if (path === "/services") {
        res.writeHead(200);
        res.write("Our Services");
        res.end();
    } else if (path === "/help") {
        res.writeHead(200);
        res.write("Help Page");
        res.end();
    } else if (path === "/blog") {
        res.writeHead(200);
        res.write("Blog page");
        res.end();
    } else if (path === "/team") {
        res.writeHead(200);
        res.write("Meet our Team");
        res.end();
    } else if (path === "/data") {
        // Handle query parameters
        const queryParams = parsedUrl.query;
        res.writeHead(200);
        res.write("Query Parameters Received:\n");
        res.write(JSON.stringify(queryParams));
        res.end();
    } else {
        res.writeHead(404);
        res.write("Page not found");
        res.end();
    }
});

server.listen(port, host, () => {
    console.log("Server running at http://" + host + ":" + port);
});
