let express = require('express')
let app = express()
let host = '127.0.0.1'
let port = 3000
app.get('/',(req,res)=>{
res.status(200)
res.send("Home")
})
app.get('/user/:id',(req,res)=>{
let userId = req.params.id
res.send(`User Id: ${userId}!`)
})
app.use((req,res)=>{
res.status(404).send("Page not found")
})
app.listen(port,(error)=>{
if (!error){
console.log("Server running on http://"+host+":"+port)
}
else{
console.log("Error loading server",error)
}
})