let express = require('express');
let app = express();
let port = 3000;
let host='127.0.0.1'

app.get('/faq', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
       
        <title>FAQ</title>
    </head>
    <body>
        <h1>Frequently Asked Questions</h1>
        <ul>
            
            <li><strong>Q2:</strong> How do I track my order?</li>
            <li><strong>Q3:</strong> Can I change my order?</li>
            <li><strong>Q4:</strong> How can I contact support?</li>
        </ul>
    </body>
    </html>
  `);
});

app.listen(port,host, () => {
  console.log(`Server running at http://127.0.0.1:3000`);
});
