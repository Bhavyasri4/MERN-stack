let url=require('url')
let baseurl="http://127.0.0.1:5000"
let relativeurl="/greet?name=bhavya"
let formaturl=url.resolve(baseurl,relativeurl)
console.log(formaturl)