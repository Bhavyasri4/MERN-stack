let express = require('express')
let app = express()
let host = '127.0.0.1'
let port = 3000
app.get('/gallery', (req, res) => {
res.send(`
<!DOCTYPE html>
<html>
<head>
<title>Image Gallery</title>
<style>
body {
font-family: Arial, sans-serif;
text-align: center;
}
.gallery {
display: flex;
flex-wrap: wrap;
justify-content: center;
gap: 10px;
padding: 20px;
}
.gallery img {
max-width: 200px;
border: 2px solid #ccc;
border-radius: 5px;
}
</style>
</head>
<body>
<h1>Image Gallery</h1>
<div class="gallery">
<img
src="https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0"
alt="Image 4">
<img
src="https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0"
alt="Image 4">
<img
src="https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0"
alt="Image 4">
<img
src="https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0"
alt="Image 4">
</div>
</body>
</html>
`);
});
app.use((req,res)=>{
res.status(404).send("page not found")
})
app.listen(port,(error)=>{
if(!error){
console.log('Server running on http://'+host+":"+port)
}
else{
console.log("Error loading Server",error)
}
})