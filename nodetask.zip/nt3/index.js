let http=require('http')
let host="127.0.0.1"
let port=5000
let server=http.createServer((req,res)=>{
    if(req.url=="/"){
    res.writeHead(200);
    res.write("Home page")
    res.end();
    }else if(req.url=="/contact"){
        res.writeHead(200);
    res.write("Contact Us")
    res.end();
    }else{
        res.writeHead(404);
    res.write("page not found")
    res.end();
    }
})
server.listen(port,host,()=>{
    console.log("server run on http://"+host+":"+port);
})