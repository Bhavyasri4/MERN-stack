let express = require('express');
let app = express();
let PORT =  3000;
let host='127.0.0.1';

app.use(express.urlencoded({ extended: true }));
app.get('/page/:title', (req, res) => {
    const title = req.params.title;
    res.send(`
        <html>
            <head>
                <title>${title}</title>
            </head>
            <body>
                <h1>${title}</h1>
                <p>This is a dynamic page with the title "${title}".</p>
            </body>
        </html>
    `);
});

app.listen(PORT,host, () => {
    console.log(`Server is running on http://localhost:3000`);
});
