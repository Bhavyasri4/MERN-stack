let express = require('express');

let app = express();
let port = 3000;
let host='127.0.0.1'
app.get('/time', (req, res) => {
  const currentTime = new Date().toISOString(); 
  res.json({ currentTime }); 
});

app.listen(port,host, () => {
  console.log(`Server is running on http://127.0.0.1:3000`);
});
